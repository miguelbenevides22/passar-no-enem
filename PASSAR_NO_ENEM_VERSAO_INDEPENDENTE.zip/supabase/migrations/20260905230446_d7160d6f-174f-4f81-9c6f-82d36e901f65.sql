-- ============================================================
-- Passar no ENEM — Fase 1: Fundação + Banco Mestre (estrutura)
-- Fonte: Banco_Mestre_V12_1_FINAL.xlsx (V12.1-F.2)
-- Matriz oficial (INEP) e taxonomia pedagógica são entidades distintas.
-- ============================================================

CREATE TABLE public.master_versions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  label TEXT NOT NULL UNIQUE,
  taxonomy_version TEXT NOT NULL,
  graph_version TEXT NOT NULL,
  mapping_version TEXT NOT NULL,
  question_version TEXT NOT NULL,
  source_file TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.master_versions TO anon, authenticated;
GRANT ALL ON public.master_versions TO service_role;
ALTER TABLE public.master_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Banco mestre é leitura pública" ON public.master_versions FOR SELECT USING (true);

-- ---------- Matriz oficial ----------
CREATE TABLE public.official_competencies (
  id TEXT NOT NULL PRIMARY KEY,
  taxonomy_version TEXT NOT NULL,
  area TEXT NOT NULL,
  number INTEGER NOT NULL,
  official_text TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (taxonomy_version, area, number)
);
GRANT SELECT ON public.official_competencies TO anon, authenticated;
GRANT ALL ON public.official_competencies TO service_role;
ALTER TABLE public.official_competencies ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Matriz oficial é leitura pública" ON public.official_competencies FOR SELECT USING (true);

CREATE TABLE public.official_skills (
  id TEXT NOT NULL PRIMARY KEY,
  taxonomy_version TEXT NOT NULL,
  code TEXT NOT NULL,
  area TEXT NOT NULL,
  competency_number INTEGER NOT NULL,
  skill_index_in_competency INTEGER NOT NULL,
  skill_number_in_area INTEGER NOT NULL,
  official_text TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (taxonomy_version, code)
);
GRANT SELECT ON public.official_skills TO anon, authenticated;
GRANT ALL ON public.official_skills TO service_role;
ALTER TABLE public.official_skills ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Habilidades oficiais são leitura pública" ON public.official_skills FOR SELECT USING (true);

CREATE TABLE public.official_objects (
  id TEXT NOT NULL PRIMARY KEY,
  taxonomy_version TEXT NOT NULL,
  area TEXT NOT NULL,
  block TEXT NOT NULL,
  official_text TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.official_objects TO anon, authenticated;
GRANT ALL ON public.official_objects TO service_role;
ALTER TABLE public.official_objects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Objetos oficiais são leitura pública" ON public.official_objects FOR SELECT USING (true);

-- ---------- Grafo pedagógico ----------
CREATE TABLE public.pedagogical_nodes (
  id TEXT NOT NULL PRIMARY KEY,
  graph_version TEXT NOT NULL,
  name TEXT NOT NULL,
  node_type TEXT NOT NULL CHECK (node_type IN ('FUNDACAO','PONTE','NUCLEO','APLICACAO','TRANSVERSAL')),
  role_description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.pedagogical_nodes TO anon, authenticated;
GRANT ALL ON public.pedagogical_nodes TO service_role;
ALTER TABLE public.pedagogical_nodes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Grafo é leitura pública" ON public.pedagogical_nodes FOR SELECT USING (true);

-- blocking/weight NÃO existem no Banco Mestre; ficam NULL até decisão explícita.
CREATE TABLE public.node_prerequisites (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  graph_version TEXT NOT NULL,
  prerequisite_node_id TEXT NOT NULL REFERENCES public.pedagogical_nodes(id) ON DELETE RESTRICT,
  dependent_node_id TEXT NOT NULL REFERENCES public.pedagogical_nodes(id) ON DELETE RESTRICT,
  blocking BOOLEAN,
  weight NUMERIC,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (graph_version, prerequisite_node_id, dependent_node_id)
);
GRANT SELECT ON public.node_prerequisites TO anon, authenticated;
GRANT ALL ON public.node_prerequisites TO service_role;
ALTER TABLE public.node_prerequisites ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Pré-requisitos são leitura pública" ON public.node_prerequisites FOR SELECT USING (true);

-- ---------- Questões ----------
CREATE TABLE public.questions (
  id TEXT NOT NULL PRIMARY KEY,
  question_version TEXT NOT NULL,
  bank_number INTEGER NOT NULL,
  exam_year INTEGER NOT NULL,
  exam_day INTEGER,
  area TEXT NOT NULL,
  discipline TEXT,
  official_answer TEXT,
  answer_english TEXT,
  answer_spanish TEXT,
  source_file TEXT,
  source_type TEXT NOT NULL,
  is_official BOOLEAN NOT NULL,
  status TEXT NOT NULL,
  is_annulled BOOLEAN NOT NULL DEFAULT false,
  raw_extract TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (question_version, bank_number)
);
GRANT SELECT ON public.questions TO anon, authenticated;
GRANT ALL ON public.questions TO service_role;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Questões são leitura pública" ON public.questions FOR SELECT USING (true);

CREATE TABLE public.question_mappings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  mapping_version TEXT NOT NULL,
  question_id TEXT NOT NULL REFERENCES public.questions(id) ON DELETE RESTRICT,
  official_skill_code TEXT NOT NULL,
  secondary_skill_code TEXT,
  official_object TEXT,
  pedagogical_content TEXT,
  pedagogical_subcontent TEXT,
  cognitive_dimension TEXT NOT NULL CHECK (cognitive_dimension IN ('RECOGNITION','EXECUTION','TRANSFER')),
  confidence NUMERIC NOT NULL,
  mapping_status TEXT NOT NULL,
  release_status TEXT NOT NULL,
  pedagogical_node_id TEXT REFERENCES public.pedagogical_nodes(id) ON DELETE RESTRICT,
  node_link_status TEXT NOT NULL CHECK (node_link_status IN ('MAPPED','AMBIGUOUS','UNMAPPED')),
  evidence_allowed BOOLEAN NOT NULL DEFAULT false,
  justification TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (mapping_version, question_id)
);
GRANT SELECT ON public.question_mappings TO anon, authenticated;
GRANT ALL ON public.question_mappings TO service_role;
ALTER TABLE public.question_mappings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Mapeamentos são leitura pública" ON public.question_mappings FOR SELECT USING (true);

-- ---------- MigrationMap ----------
CREATE TABLE public.migration_map (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  migration_version TEXT NOT NULL,
  legacy_kind TEXT NOT NULL CHECK (legacy_kind IN ('NODE','QUESTION','DIMENSION','MASTERY')),
  legacy_key TEXT NOT NULL,
  target_id TEXT,
  status TEXT NOT NULL CHECK (status IN ('MAPPED','AMBIGUOUS','UNMAPPED','NOT_APPLICABLE')),
  reason TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (migration_version, legacy_kind, legacy_key)
);
GRANT SELECT ON public.migration_map TO anon, authenticated;
GRANT ALL ON public.migration_map TO service_role;
ALTER TABLE public.migration_map ENABLE ROW LEVEL SECURITY;
CREATE POLICY "MigrationMap é leitura pública" ON public.migration_map FOR SELECT USING (true);

-- ---------- Relatório de validação ----------
CREATE TABLE public.import_validations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  master_version_label TEXT NOT NULL,
  check_name TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('PASS','FAIL','INFO')),
  detail TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.import_validations TO anon, authenticated;
GRANT ALL ON public.import_validations TO service_role;
ALTER TABLE public.import_validations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Validações são leitura pública" ON public.import_validations FOR SELECT USING (true);

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_master_versions_updated_at
BEFORE UPDATE ON public.master_versions
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();