REVOKE EXECUTE ON FUNCTION public.evaluate_evidence_gate(text, text) FROM anon, authenticated, PUBLIC;
GRANT EXECUTE ON FUNCTION public.evaluate_evidence_gate(text, text) TO service_role;
REVOKE EXECUTE ON FUNCTION public.record_attempt(jsonb) FROM anon, PUBLIC;
GRANT EXECUTE ON FUNCTION public.record_attempt(jsonb) TO authenticated, service_role;