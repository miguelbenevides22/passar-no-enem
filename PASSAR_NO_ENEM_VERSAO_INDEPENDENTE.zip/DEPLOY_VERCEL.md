# Publicar o PASSAR NO ENEM fora da Lovable

## 1. Criar o repositório

- Crie um repositório vazio no GitHub, por exemplo `passar-no-enem`.
- Envie **todo o conteúdo desta pasta** para a raiz do repositório.
- Não envie nenhum `.env` com segredos. Use `.env.example` apenas como modelo.

## 2. Importar na Vercel

- Entre na Vercel.
- Clique em **Add New → Project**.
- Escolha o repositório `passar-no-enem`.
- A Vercel deve detectar TanStack Start.
- Build command: `npm run build`.
- Não altere o framework para Next.js.

## 3. Variáveis de ambiente

Na Vercel, adicione as variáveis do seu ambiente Supabase:

- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_PROJECT_ID`
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`
- `VITE_SUPABASE_PROJECT_ID`

Use os valores do ambiente Supabase que já alimenta o projeto atual. Nunca coloque service-role key no navegador nem em `VITE_*`.

## 4. Deploy

Clique em **Deploy**.

## 5. Auth do Supabase

Depois que a Vercel gerar o domínio, cadastre esse domínio nas configurações de URL/Redirect do Supabase. O fluxo de confirmação de e-mail usa `window.location.origin`.

## 6. Teste obrigatório

1. Home
2. Criar conta
3. Confirmar e-mail
4. Entrar
5. Missão
6. Estudo
7. Painel
8. Sair
9. Entrar novamente

## Observação

A hospedagem da aplicação fica independente da Lovable. O projeto ainda depende do serviço Supabase configurado nas variáveis de ambiente para autenticação e dados. A migração completa do banco para um projeto Supabase controlado diretamente por nós pode ser feita depois, sem precisar reconstruir a aplicação.
