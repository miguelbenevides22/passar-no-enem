-- ============ ATTEMPTS ============
CREATE TABLE public.attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  question_id text NOT NULL REFERENCES public.questions(id) ON DELETE RESTRICT,
  mapping_version text NOT NULL,
  selected_answer text,
  is_correct boolean NOT NULL,
  response_time_ms integer,
  attempt_context text NOT NULL CHECK (attempt_context IN ('MISSION','SIMULATION','REVIEW','FREE')),
  evidence_status text NOT NULL CHECK (evidence_status IN ('ACCEPTED','REJECTED')),
  rejection_reason text,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX attempts_user_idx ON public.attempts (user_id, occurred_at DESC);
GRANT SELECT, INSERT ON public.attempts TO authenticated;
GRANT ALL ON public.attempts TO service_role;
ALTER TABLE public.attempts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Estudante lê as próprias tentativas" ON public.attempts FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Estudante cria as próprias tentativas" ON public.attempts FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- ============ EVIDENCES ============
CREATE TABLE public.evidences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  attempt_id uuid NOT NULL UNIQUE REFERENCES public.attempts(id) ON DELETE RESTRICT,
  user_id uuid NOT NULL,
  question_id text NOT NULL REFERENCES public.questions(id) ON DELETE RESTRICT,
  pedagogical_node_id text NOT NULL REFERENCES public.pedagogical_nodes(id) ON DELETE RESTRICT,
  official_skill_code text NOT NULL,
  cognitive_dimension text NOT NULL CHECK (cognitive_dimension IN ('RECOGNITION','EXECUTION','TRANSFER')),
  is_correct boolean NOT NULL,
  weight numeric NOT NULL,
  is_official_question boolean NOT NULL,
  mapping_version text NOT NULL,
  graph_version text NOT NULL,
  engine_version text NOT NULL,
  occurred_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX evidences_user_node_idx ON public.evidences (user_id, pedagogical_node_id, occurred_at);
GRANT SELECT ON public.evidences TO authenticated;
GRANT ALL ON public.evidences TO service_role;
ALTER TABLE public.evidences ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Estudante lê as próprias evidências" ON public.evidences FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- ============ DIAGNOSES ============
CREATE TABLE public.diagnoses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  pedagogical_node_id text NOT NULL REFERENCES public.pedagogical_nodes(id) ON DELETE RESTRICT,
  evidence_id uuid REFERENCES public.evidences(id) ON DELETE RESTRICT,
  diagnosis_state text NOT NULL CHECK (diagnosis_state IN ('UNKNOWN','GAP','FRAGILE','DEVELOPING','CONSOLIDATED')),
  fragility numeric NOT NULL,
  evidence_count integer NOT NULL,
  correct_count integer NOT NULL,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  engine_version text NOT NULL,
  occurred_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX diagnoses_user_node_idx ON public.diagnoses (user_id, pedagogical_node_id, occurred_at DESC);
GRANT SELECT ON public.diagnoses TO authenticated;
GRANT ALL ON public.diagnoses TO service_role;
ALTER TABLE public.diagnoses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Estudante lê os próprios diagnósticos" ON public.diagnoses FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- ============ MASTERY ============
CREATE TABLE public.mastery_states (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  pedagogical_node_id text NOT NULL REFERENCES public.pedagogical_nodes(id) ON DELETE RESTRICT,
  mastery numeric NOT NULL DEFAULT 0,
  evidence_count integer NOT NULL DEFAULT 0,
  correct_count integer NOT NULL DEFAULT 0,
  last_evidence_at timestamptz,
  engine_version text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, pedagogical_node_id)
);
GRANT SELECT ON public.mastery_states TO authenticated;
GRANT ALL ON public.mastery_states TO service_role;
ALTER TABLE public.mastery_states ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Estudante lê o próprio domínio" ON public.mastery_states FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE TRIGGER update_mastery_states_updated_at BEFORE UPDATE ON public.mastery_states FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ RETENTION ============
CREATE TABLE public.retention_states (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  pedagogical_node_id text NOT NULL REFERENCES public.pedagogical_nodes(id) ON DELETE RESTRICT,
  retention numeric NOT NULL DEFAULT 0,
  stability_days numeric NOT NULL DEFAULT 1,
  review_count integer NOT NULL DEFAULT 0,
  lapse_count integer NOT NULL DEFAULT 0,
  last_review_at timestamptz,
  next_review_at timestamptz,
  engine_version text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, pedagogical_node_id)
);
GRANT SELECT ON public.retention_states TO authenticated;
GRANT ALL ON public.retention_states TO service_role;
ALTER TABLE public.retention_states ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Estudante lê a própria retenção" ON public.retention_states FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE TRIGGER update_retention_states_updated_at BEFORE UPDATE ON public.retention_states FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ AUDIT ============
CREATE TABLE public.audit_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  event_type text NOT NULL,
  subject_kind text NOT NULL,
  subject_id text,
  decision jsonb NOT NULL,
  decision_hash text NOT NULL,
  engine_version text NOT NULL,
  occurred_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_events_user_idx ON public.audit_events (user_id, occurred_at DESC);
GRANT SELECT ON public.audit_events TO authenticated;
GRANT ALL ON public.audit_events TO service_role;
ALTER TABLE public.audit_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Estudante lê a própria auditoria" ON public.audit_events FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- ============ MAPPING REVIEW QUEUE ============
CREATE TABLE public.mapping_review_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mapping_version text NOT NULL,
  question_id text NOT NULL REFERENCES public.questions(id) ON DELETE RESTRICT,
  official_skill_code text NOT NULL,
  official_object text,
  pedagogical_content text,
  pedagogical_subcontent text,
  current_mapping_status text NOT NULL,
  node_link_status text NOT NULL,
  pending_reason text NOT NULL,
  candidate_node_ids text[] NOT NULL DEFAULT '{}',
  review_status text NOT NULL DEFAULT 'PENDING' CHECK (review_status IN ('PENDING','RESOLVED','DISCARDED')),
  resolved_node_id text REFERENCES public.pedagogical_nodes(id) ON DELETE RESTRICT,
  resolved_by uuid,
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (mapping_version, question_id)
);
GRANT SELECT ON public.mapping_review_queue TO authenticated;
GRANT SELECT ON public.mapping_review_queue TO anon;
GRANT ALL ON public.mapping_review_queue TO service_role;
ALTER TABLE public.mapping_review_queue ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Fila de revisão é leitura pública" ON public.mapping_review_queue FOR SELECT USING (true);
CREATE TRIGGER update_mapping_review_queue_updated_at BEFORE UPDATE ON public.mapping_review_queue FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ EVIDENCE GATE (server-side, autoritativo) ============
CREATE OR REPLACE FUNCTION public.evaluate_evidence_gate(_question_id text, _mapping_version text)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  q public.questions%ROWTYPE;
  m public.question_mappings%ROWTYPE;
BEGIN
  SELECT * INTO q FROM public.questions WHERE id = _question_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'QUESTION_NOT_FOUND');
  END IF;
  IF q.is_annulled THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'QUESTION_ANNULLED');
  END IF;
  IF q.status IS DISTINCT FROM 'ATIVA' THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'QUESTION_NOT_ACTIVE');
  END IF;

  SELECT * INTO m FROM public.question_mappings
   WHERE question_id = _question_id AND mapping_version = _mapping_version;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'MAPPING_NOT_FOUND');
  END IF;
  IF m.release_status IS DISTINCT FROM 'SIM' OR m.mapping_status IS DISTINCT FROM 'VALIDADO' THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'MAPPING_QUARANTINED');
  END IF;
  IF m.node_link_status <> 'MAPPED' OR m.pedagogical_node_id IS NULL THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'MAPPING_NOT_UNAMBIGUOUS');
  END IF;
  IF NOT m.evidence_allowed THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'EVIDENCE_NOT_ALLOWED');
  END IF;

  RETURN jsonb_build_object(
    'allowed', true,
    'reason', NULL,
    'pedagogical_node_id', m.pedagogical_node_id,
    'official_skill_code', m.official_skill_code,
    'cognitive_dimension', m.cognitive_dimension,
    'is_official_question', q.is_official
  );
END;
$$;
REVOKE ALL ON FUNCTION public.evaluate_evidence_gate(text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.evaluate_evidence_gate(text, text) TO authenticated, service_role;

-- ============ TRANSAÇÃO COMPLETA ============
CREATE OR REPLACE FUNCTION public.record_attempt(_payload jsonb)
RETURNS jsonb
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _user uuid := auth.uid();
  _question_id text := _payload->>'question_id';
  _mapping_version text := _payload->>'mapping_version';
  _engine text := _payload->>'engine_version';
  _occurred timestamptz := (_payload->>'occurred_at')::timestamptz;
  _is_correct boolean := (_payload->>'is_correct')::boolean;
  gate jsonb;
  _attempt_id uuid;
  _evidence_id uuid;
  _diagnosis_id uuid;
  _node text;
BEGIN
  IF _user IS NULL THEN
    RAISE EXCEPTION 'UNAUTHENTICATED';
  END IF;

  gate := public.evaluate_evidence_gate(_question_id, _mapping_version);

  INSERT INTO public.attempts (user_id, question_id, mapping_version, selected_answer, is_correct,
                               response_time_ms, attempt_context, evidence_status, rejection_reason, occurred_at)
  VALUES (_user, _question_id, _mapping_version, _payload->>'selected_answer', _is_correct,
          NULLIF(_payload->>'response_time_ms','')::int, _payload->>'attempt_context',
          CASE WHEN (gate->>'allowed')::boolean THEN 'ACCEPTED' ELSE 'REJECTED' END,
          gate->>'reason', _occurred)
  RETURNING id INTO _attempt_id;

  IF NOT (gate->>'allowed')::boolean THEN
    INSERT INTO public.audit_events (user_id, event_type, subject_kind, subject_id, decision, decision_hash, engine_version, occurred_at)
    VALUES (_user, 'EVIDENCE_REJECTED', 'ATTEMPT', _attempt_id::text,
            jsonb_build_object('gate', gate, 'attempt_id', _attempt_id, 'question_id', _question_id),
            _payload->>'decision_hash', _engine, _occurred);
    RETURN jsonb_build_object('attempt_id', _attempt_id, 'accepted', false, 'reason', gate->>'reason');
  END IF;

  _node := gate->>'pedagogical_node_id';

  INSERT INTO public.evidences (attempt_id, user_id, question_id, pedagogical_node_id, official_skill_code,
                                cognitive_dimension, is_correct, weight, is_official_question, mapping_version,
                                graph_version, engine_version, occurred_at)
  VALUES (_attempt_id, _user, _question_id, _node, gate->>'official_skill_code',
          gate->>'cognitive_dimension', _is_correct, (_payload->>'weight')::numeric,
          (gate->>'is_official_question')::boolean, _mapping_version,
          _payload->>'graph_version', _engine, _occurred)
  RETURNING id INTO _evidence_id;

  INSERT INTO public.mastery_states (user_id, pedagogical_node_id, mastery, evidence_count, correct_count, last_evidence_at, engine_version)
  VALUES (_user, _node, (_payload->'mastery'->>'mastery')::numeric,
          (_payload->'mastery'->>'evidence_count')::int, (_payload->'mastery'->>'correct_count')::int, _occurred, _engine)
  ON CONFLICT (user_id, pedagogical_node_id) DO UPDATE
    SET mastery = EXCLUDED.mastery,
        evidence_count = EXCLUDED.evidence_count,
        correct_count = EXCLUDED.correct_count,
        last_evidence_at = EXCLUDED.last_evidence_at,
        engine_version = EXCLUDED.engine_version;

  INSERT INTO public.retention_states (user_id, pedagogical_node_id, retention, stability_days, review_count, lapse_count, last_review_at, next_review_at, engine_version)
  VALUES (_user, _node, (_payload->'retention'->>'retention')::numeric,
          (_payload->'retention'->>'stability_days')::numeric,
          (_payload->'retention'->>'review_count')::int,
          (_payload->'retention'->>'lapse_count')::int,
          _occurred, (_payload->'retention'->>'next_review_at')::timestamptz, _engine)
  ON CONFLICT (user_id, pedagogical_node_id) DO UPDATE
    SET retention = EXCLUDED.retention,
        stability_days = EXCLUDED.stability_days,
        review_count = EXCLUDED.review_count,
        lapse_count = EXCLUDED.lapse_count,
        last_review_at = EXCLUDED.last_review_at,
        next_review_at = EXCLUDED.next_review_at,
        engine_version = EXCLUDED.engine_version;

  INSERT INTO public.diagnoses (user_id, pedagogical_node_id, evidence_id, diagnosis_state, fragility,
                                evidence_count, correct_count, details, engine_version, occurred_at)
  VALUES (_user, _node, _evidence_id, _payload->'diagnosis'->>'state',
          (_payload->'diagnosis'->>'fragility')::numeric,
          (_payload->'mastery'->>'evidence_count')::int,
          (_payload->'mastery'->>'correct_count')::int,
          COALESCE(_payload->'diagnosis'->'details', '{}'::jsonb), _engine, _occurred)
  RETURNING id INTO _diagnosis_id;

  INSERT INTO public.audit_events (user_id, event_type, subject_kind, subject_id, decision, decision_hash, engine_version, occurred_at)
  VALUES (_user, 'EVIDENCE_ACCEPTED', 'EVIDENCE', _evidence_id::text,
          jsonb_build_object('gate', gate, 'attempt_id', _attempt_id, 'evidence_id', _evidence_id,
                             'diagnosis', _payload->'diagnosis', 'mastery', _payload->'mastery',
                             'retention', _payload->'retention'),
          _payload->>'decision_hash', _engine, _occurred);

  RETURN jsonb_build_object('attempt_id', _attempt_id, 'accepted', true, 'evidence_id', _evidence_id,
                            'diagnosis_id', _diagnosis_id, 'pedagogical_node_id', _node);
END;
$$;
REVOKE ALL ON FUNCTION public.record_attempt(jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.record_attempt(jsonb) TO authenticated, service_role;