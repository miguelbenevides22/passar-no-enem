CREATE OR REPLACE FUNCTION public.evaluate_evidence_gate(_question_id text, _mapping_version text)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  q public.questions%ROWTYPE;
  m public.question_mappings%ROWTYPE;
BEGIN
  SELECT * INTO q FROM public.questions WHERE id = _question_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'QUESTION_NOT_FOUND');
  END IF;
  IF q.is_annulled THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'QUESTION_ANNULLED');
  END IF;
  IF q.status NOT IN ('ATIVA', 'RAW_EXTRACT') THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'QUESTION_NOT_ACTIVE');
  END IF;

  SELECT * INTO m FROM public.question_mappings
   WHERE question_id = _question_id AND mapping_version = _mapping_version;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'MAPPING_NOT_FOUND');
  END IF;
  IF m.release_status IS DISTINCT FROM 'SIM' OR m.mapping_status IS DISTINCT FROM 'VALIDADO' THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'MAPPING_QUARANTINED');
  END IF;
  IF m.node_link_status <> 'MAPPED' OR m.pedagogical_node_id IS NULL THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'MAPPING_NOT_UNAMBIGUOUS');
  END IF;
  IF NOT m.evidence_allowed THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'EVIDENCE_NOT_ALLOWED');
  END IF;

  RETURN jsonb_build_object(
    'allowed', true,
    'reason', NULL,
    'pedagogical_node_id', m.pedagogical_node_id,
    'official_skill_code', m.official_skill_code,
    'cognitive_dimension', m.cognitive_dimension,
    'is_official_question', q.is_official
  );
END;
$function$;