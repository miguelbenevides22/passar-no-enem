REVOKE ALL ON FUNCTION public.evaluate_evidence_gate(text, text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.record_attempt(jsonb) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.update_updated_at_column() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.evaluate_evidence_gate(text, text) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.record_attempt(jsonb) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.update_updated_at_column() TO service_role;